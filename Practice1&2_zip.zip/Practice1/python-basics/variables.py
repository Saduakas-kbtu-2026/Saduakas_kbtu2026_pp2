x = 5.0 # float
y = 2  # int
z = "i love python" # string

print(type(x))
print(type(y))
print(type(z))
