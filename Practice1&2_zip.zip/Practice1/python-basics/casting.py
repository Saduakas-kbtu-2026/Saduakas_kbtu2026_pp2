#ints can be converted to floats and strings
x = 1
y = 2.8
z = "4"

print(int(x), int(y), int(z))       # 1     | 2     | 4
print(float(x), float(y), float(z)) # 1.0   | 2.8   | 4.0
print(str(x), str(y), str(z))       # 1     | 2.8   | 4