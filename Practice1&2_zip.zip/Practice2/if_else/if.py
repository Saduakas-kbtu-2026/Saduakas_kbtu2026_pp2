a = 33
b = 200
if b > a:
  print("b is greater than a")# is printed

number = 15
if number > 0:
  print("The number is positive") # is also printed

age = 20
if age >= 18:
  print("You are an adult")
  print("You can vote")
  print("You have full legal rights")# prints multiple statements one after another

is_logged_in = True
if is_logged_in:
  print("Welcome back!")#printed

if a < b and is_logged_in:
  print("when they stopped to make their play")

if number < 30 or not is_logged_in:
    print("when he tried to match the ranger with big iron on his hip")