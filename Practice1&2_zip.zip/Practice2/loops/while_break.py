i = 1
while i < 6:
  print(i)
  if i == 3:
    break # stops loops when condition is met
  i += 1 