coord = list(map(int, input().split())) # n, l ,r
numbers = list(map(int, input().split()))
n = coord[0]
l = coord[1]
r = coord[2]

chosen_list = []

for i in range(r-l): # 5 - 2 = 3
    chosen_list += numbers[l - n + i]

chosen_list.sort()
chosen_list.reverse()
print(chosen_list)