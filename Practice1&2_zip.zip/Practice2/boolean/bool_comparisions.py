print(10 > 9) #true
print(10 == 9)#false
print(10 < 9) #false

a = 200
b = 33

if b > a:
  print("b is greater than a")     #false
else:
  print("b is not greater than a") #true
